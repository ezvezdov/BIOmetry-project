function [imSegmented imContour] = segmentimage(imOriginal, tresh, DOPLNIT)

%[imSegmented imContour] = segmentimage(imOriginal, blkSize, enh, smooth)
%
% Funkce segmentuje obrazek na otisk a pozadi.
%
%   imOriginal - vstupni otisk
%   tresh - prah pro segmentaci otisku
%
%
% vystupy: 
%   imSegmented - binarni obrazek stejne velikosti jako imOriginal, 1
%       oznacuje otisk a 0 znaci pozadi
%   imContour - kontura segmentace binarni obrazek obsahujici pouze
%   konturu, ne celou plochu segmentace

if nargin < 2
    tresh = 3;
end

%%
% Doplnte
%%