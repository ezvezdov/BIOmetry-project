function [matchingScore, nbmatch, inputmatch, dbmatch] = match(mAi1, mAi2)

% Porovnani dvou otisku pomoci parovani markantu.
%
% [matchingScore, nbmatch, inputmatch, dbmatch] = match(mAi1, mAi2)
%
%   vstupy: mAi1 - pole s markanty z databazoveho obrazku, stejne velike
%               jako originalni obrazek otisku.
%           mAi2 - pole s markanty z porovnavaneho obrazku, otisky a tedy i polohy
%               markantu musi byt co nejlepe srovnany. stejne velike jako
%               originalni obrazek otisku.
%
%   vystupy: matchingScore - ohodnoceni p�i�azen� otisk�
%            nbmatch - pocet paru markantu
%            inputmatch - pole (stejne velikosti jako vstupni obrazek) s
%               vyznacenymi markanty ve vstupnim obrazku (mAi2) sparovane s
%               markanty ze zrovnavaneho obrazku.
%            dbmatch - pole (stejne velikosti jako vstupni obrazek) s
%               vyznacenymi markanty ve vstupnim obrazku (mAi2) sparovane s
%               markanty ze zrovnavaneho obrazku.

warning off all

dbMinutiap = double(bwmorph(mAi1, 'Shrink', 'Inf'));
inputMinutiap = double(bwmorph(mAi2, 'Shrink', 'Inf'));

[x,y]=find(dbMinutiap);
for i=1:length(x)
    dbMinutiap(x(i),y(i))=mAi1(x(i),y(i));
end

[x,y]=find(inputMinutiap);
for i=1:length(x)
    inputMinutiap(x(i),y(i))=mAi2(x(i),y(i));
end


[matchingScore,~, ~,nbmatch, inputmatch, dbmatch]= score(dbMinutiap ,inputMinutiap);
 
%--------------------------------------------------------------------------
function [matchingscore, nbElementInput, nbElement, nbmatch, inputmatch, dbmatch] = score(db, input)
%Vstupy:
% db - pole, stejne velikosti jako vstupni obraz, s vyznacenymi markanty.
%   odpovida obrazu, ktery slouzi jako vzor.
% input - pole, stejne velikosti jako vstupni obraz, s vyznacenymi markanty.
%   odpovida obrazu, ktery slouzi jako porovnavany vstup.
%
%Vystupy:
% matchingScore - ohodnoceni p�i�azen� otisk�
% nbElementInput - pocet markantu ve srovnavacim obraze
% nbelement - celkovy pocet markantu v obou vstupnich polich
% nbmatch - pocet paru markantu
% inputmatch - pole (stejne velikosti jako vstupni obrazek) s
%   vyznacenymi markanty ve vstupnim obrazku (mAi2) sparovane s
%   markanty ze zrovnavaneho obrazku.
% dbmatch - pole (stejne velikosti jako vstupni obrazek) s
%   vyznacenymi markanty ve vstupnim obrazku (mAi2) sparovane s
%   markanty ze zrovnavaneho obrazku.

threshold =  12;


% DOPLNIT


fprintf('number of matched minutiae : %d\ndistance total computed : %d\n',nbmatch, distot);
fprintf('number of minutiae in input image : %d\n', nbElementInput);
fprintf('number of minutiae in database image : %d\n', nbElementDb);
fprintf('Score for minutiae : %1.2g\n', matchingscore);



