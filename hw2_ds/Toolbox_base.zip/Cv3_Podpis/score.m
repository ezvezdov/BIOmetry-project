function sc = score(mode, signatures, model)
% sc = score(mode, signatures, model)
% funkce pocitajici score daneho modelu

switch mode
    case'GMM'
        sc = zeros(1, numel(signatures)); % ulozime pravdepodobnosti ze dany podpis (z test) odpovida modelu
        for m = 1 : numel(signatures)
            for n = 1 : numel(model)
                p = pdf(model{n}, signatures{m}(:, n)); % vypocet pdf pro kazdy bod podpisu
                sc(m) = sc(m) + sum(log(p)); % zlogaritmujeme a secteme
            end
        end
    case 'DTW'
        %algoritmus pro porovnani pomoci DTW
end