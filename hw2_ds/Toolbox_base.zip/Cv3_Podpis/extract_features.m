function data = extract_features(mode, data)
% data = extract_features(mode, data)
% funkce pro extrakci priznaku z dat

switch mode
    case 'xyp'
        data = data;
        % mozne doplnit pridani dalsich priznaku k datum
end
