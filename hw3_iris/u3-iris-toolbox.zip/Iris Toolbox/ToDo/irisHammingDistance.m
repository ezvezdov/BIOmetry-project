% irisHammingDistance - calculate hamming distance between two iris codes
% with noise masks

% USAGE:
%   HD = irisHammingDistance(codeA,codeB, maskA, maskB) 
%   codeA, codeB - irisCodes
%   maskA, maskB - corresponding noise masks

function HD = irisHammingDistance(codeA,codeB, maskA, maskB) 

% ----------------------------

% implement your task here

error('function not implemented!')

% ----------------------------