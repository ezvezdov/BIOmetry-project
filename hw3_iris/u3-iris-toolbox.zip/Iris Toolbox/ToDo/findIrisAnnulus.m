% findIrisAnnulus - find circular iris boudaries in the input eye image
%
% USAGE:
%   [circlePupil, circleIris] = findIrisAnnulus(eyeimage)
%    circlePupil - inner iris edge circle parameter vector [x,y,radius]
%    circleIris - outer iris edge circle parameter vector [x,y,radius]
%
% E. Bakstein 21.11.2011
% Based on original Iris Toolbox by Libor Masek

function [circlepupil, circleiris] = findIrisAnnulus(eyeimage)

% ------------------------
% Your code goes here
error('findIrisAnnulus not implemented')
% ------------------------