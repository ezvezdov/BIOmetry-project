% walkDatabase.m - load irisCode database and iterate through it

% E. Bakstein 21.11.2011

% initialize iris toolbox
iris_init;

% the database, containing calculated irisCode images
load database.mat

sides = 'LR';

for subject = 1:length(database)
    
    for side = 1:2
        for image = 1:length(database(subject).(sides(side)))
            template = database(subject).(sides(side))(image).template;
            mask = database(subject).(sides(side))(image).mask;
            
            % display current progress
            %disp([num2str(subject) ' > ' sides(side) num2str(image)])
            
            % ---------------------------------------------------
            
            % your calls to IrisCode comparing function(s) go here
            
            % ---------------------------------------------------
        end
    end
end
